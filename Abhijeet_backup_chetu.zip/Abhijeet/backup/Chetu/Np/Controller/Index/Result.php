<?php
 
namespace Chetu\Np\Controller\Index;
 
use Magento\Framework\App\Action\Action;
use Magento\Framework\App\Action\Context;
use Magento\Framework\Controller\ResultFactory;
use Magento\Framework\UrlInterface;
use Magento\Framework\View\Result\PageFactory;
use Chetu\Np\Model\DataSampleFactory;
use Magento\Framework\App\CsrfAwareActionInterface;
use Magento\Framework\App\Request\InvalidRequestException;
use Magento\Framework\App\RequestInterface;

class Result extends Action implements CsrfAwareActionInterface
{
    protected $resultPageFactory;
    protected $datasampleFactory;
    private $url;
 
    public function __construct(
        UrlInterface $url,
        Context $context,
        PageFactory $resultPageFactory,
        DataSampleFactory $datasampleFactory
    )
    {
        $this->resultPageFactory = $resultPageFactory;
        $this->datasampleFactory = $datasampleFactory;
        $this->url = $url;
        parent::__construct($context);
    }
        
    public function execute()
    {   print_r($_POST); 
        $model = $this->datasampleFactory->create();
        $emp_name = $this->getRequest()->getParam('employee_name');
        $emp_age = $this->getRequest()->getParam('employee_age');
        $emp_description= $this->getRequest()->getParam('employee_description');
        $emp_color= $this->getRequest()->getParam('employee_color');
        $emp_address= $this->getRequest()->getParam('employee_address');
        $emp_gender= $this->getRequest()->getParam('employee_gender');
        if(!empty($emp_name && $emp_age && $emp_age && $emp_description && $emp_color && $emp_address && $emp_gender)){
            $this->messageManager->addSuccess( __('All Data Fields are Filled') );
    
            $model->addData([
                    "employee_name" => $emp_name,
                    "employee_age" => $emp_age,
                    "employee_description" => $emp_description,
                    "employee_color" => $emp_color,
                    "employee_address" => $emp_address,
                    "employee_gender" => $emp_gender,
                    "sort_order" => 1
                    ]);
        }
        else{$this->messageManager->addErrorMessage( __('Form Input Field are Empty !') );}
        $saveData = $model->save();
        
    if($saveData){$this->messageManager->addSuccessMessage( __('Insert Record Successfully !') );}
    $resultRedirect = $this->resultFactory->create(ResultFactory::TYPE_REDIRECT);
    $resultRedirect->setUrl($this->url->getUrl('uiform/index/dispdata'));
    return $resultRedirect;

    }
    public function createCsrfValidationException(RequestInterface $request): ?InvalidRequestException
    {
        return null;
    }
 
    public function validateForCsrf(RequestInterface $request): ?bool
    {
        return true;
    }
}