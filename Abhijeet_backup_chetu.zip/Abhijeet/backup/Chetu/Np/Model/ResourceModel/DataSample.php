<?php 
    namespace Chetu\Np\Model\ResourceModel;
    class DataSample extends \Magento\Framework\Model\ResourceModel\Db\AbstractDb{
        public function _construct(){
            $this->_init("ui_comp_form","employee_id");
        }
    }
    ?>