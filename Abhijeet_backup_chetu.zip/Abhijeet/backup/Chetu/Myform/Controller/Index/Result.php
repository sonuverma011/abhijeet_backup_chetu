<?php

namespace Chetu\Myform\Controller\Index;

use Chetu\Myform\Model\EmpGridFactory;
use Magento\Framework\App\Action\Context;
use Magento\Framework\View\Result\PageFactory;
use Magento\Framework\Controller\Result\JsonFactory;
use Magento\Framework\App\CsrfAwareActionInterface;
use Magento\Framework\App\Request\InvalidRequestException;
use Magento\Framework\App\RequestInterface;

class Result extends \Magento\Framework\App\Action\Action implements CsrfAwareActionInterface
{

     /**
     * @var Magento\Framework\View\Result\PageFactory
     */
    protected $resultPageFactory;

    protected $resultJsonFactory; 

    protected $empgridFactory;

    /**
     * @param Context     $context
     * @param PageFactory $resultPageFactory
     */

    public function __construct(
        Context $context,
        PageFactory $resultPageFactory,
        JsonFactory $resultJsonFactory,
        EmpGridFactory $empgridFactory
        )
    {

        $this->resultPageFactory = $resultPageFactory;
        $this->resultJsonFactory = $resultJsonFactory; 
        $this->empgridFactory = $empgridFactory;
        return parent::__construct($context);
    }
    
    public function execute()
    {
        $empgridFactory = $this->empgridFactory->create();
        $empgridFactory = $this->getRequest()->getParam('searchvalue');
        $result = $this->resultJsonFactory->create();
        $resultPage = $this->resultPageFactory->create();
        
        $block = $resultPage->getLayout()->getblock('index_result')->setData('searchvalue',$empgridFactory);

        $resultPage->getConfig()->getTitle()->set('Showing Search Results');
        return $resultPage;
    }

    public function createCsrfValidationException(RequestInterface $request): ?InvalidRequestException
    {
        return null;
    }

    public function validateForCsrf(RequestInterface $request): ?bool
    {
        return true;    
    }
} 
