<?php

namespace Chetu\Myform\Controller\Adminhtml\Create;

use Magento\Framework\Controller\ResultFactory;

class AddEmployee extends \Magento\Backend\App\Action
{
    /**
     * @var \Magento\Framework\Registry
     */
    private $coreRegistry;

    /**
     * @var \Chetu\Myform\Model\EmpGridFactory
     */
    private $empgridFactory;

    public function __construct(
        \Magento\Backend\App\Action\Context $context,
        \Magento\Framework\Registry $coreRegistry,
        \Chetu\Myform\Model\EmpGridFactory $empgridFactory   
    ) {
        parent::__construct($context);
        $this->coreRegistry = $coreRegistry;
        $this->empgridFactory = $empgridFactory;
    }

    /**
     * Mapped Grid List page.
     * @return \Magento\Backend\Model\View\Result\Page
     */
    public function execute()
    {
        $empId = (int) $this->getRequest()->getParam('employee_id');
        $empData = $this->empgridFactory->create();
        /** @var \Magento\Backend\Model\View\Result\Page $resultPage */
        if ($empId) {
            $empData = $empData->load($empId);
            $empName = $empData->getEmployeeName();
            if (!$empData->getEmployeeId()) {
                $this->messageManager->addError(__('row data no longer exist.'));
                $this->_redirect('agrid/create/index');
                return;
            }
        }

        $this->coreRegistry->register('emp_data', $empData);
        $resultPage = $this->resultFactory->create(ResultFactory::TYPE_PAGE);
        $title = $empId ? __('Edit Employee Data ').$empName : __('Add Employee Data');
        $resultPage->getConfig()->getTitle()->prepend($title);
        return $resultPage;
    }

    protected function _isAllowed()
    {
        return $this->_authorization->isAllowed('Chetu_Myform::add_employee');
    }
}