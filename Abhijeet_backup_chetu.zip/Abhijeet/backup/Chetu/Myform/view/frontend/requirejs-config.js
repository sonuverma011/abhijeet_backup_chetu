var config = {
    map: {
        '*': {
            myformjs: 'Chetu_Myform/js/myform',
        }
    }
};