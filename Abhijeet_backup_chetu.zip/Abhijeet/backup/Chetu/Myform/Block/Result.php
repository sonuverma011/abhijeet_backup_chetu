<?php

namespace Chetu\Myform\Block;

use \Magento\Framework\View\Element\Template;
use \Magento\Framework\View\Element\Template\Context;
use Chetu\Myform\Model\ResourceModel\Empgrid\CollectionFactory;

class Result extends Template
{

    public function __construct(Context $context,      
        CollectionFactory $collectionFactory,
        \Magento\Store\Model\StoreManagerInterface $storeManager
    )
    {        
        $this->_storeManager = $storeManager;
        $this->collection = $collectionFactory;
        parent::__construct($context);
    }

    public function getCollection()
    {
        return $this->collection->create();
    }

    public function getBaseUrl()
    {
        return $this->_storeManager->getStore()->getBaseUrl();
    }

    public function getSearchvalueData()
    {
        return $this->getSearchvalue();
    }
}