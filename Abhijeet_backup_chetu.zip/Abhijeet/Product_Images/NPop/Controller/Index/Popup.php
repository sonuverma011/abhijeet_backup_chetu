<?php
namespace Chetu\NPop\Controller\Index;

class Popup extends \Magento\Framework\App\Action\Action
{
	protected $_pageFactory;

	public function __construct(
		\Magento\Framework\App\Action\Context $context,
		\Magento\Framework\View\Result\PageFactory $pageFactory,
		\Magento\Framework\App\ResourceConnection $resource,
		\Magento\Customer\Model\CustomerFactory $customerFactory)
	{
		$this->_pageFactory = $pageFactory;
		$this->_resource = $resource;
		$this->customerFactory = $customerFactory;
		return parent::__construct($context);
	}

	public function execute()
	{
		$connection = $this->_resource;// if (!$conn){
			//     echo "Connection to the database failed."; 
			// }else{
			// echo "Successfully connected to the database";
			// }
			// echo "<br>";
		$conn=$connection->getConnection();

		$fname = $this->getRequest()->getParam('firstName');
		$lname = $this->getRequest()->getParam('lastName');
		$email = $this->getRequest()->getParam('email');
		$gender = $this->getRequest()->getParam('gender');
		
		$name = $fname.' '.$lname;

		$sql = "INSERT INTO `custum_popup_data`(`name`, `gender`, `email`)  VALUES ('$name','$email','$gender')";

		$conn->query($sql);
		echo "<script>alert('Successfully Submitted the Data')</script>";	

		}
	
} 
		/*
		$connection = $this->_resource;
		$conn=$connection->getConnection();
		if (!$conn){
			    echo "Not Connected to database."; 
			}
			else{
				echo "Successfully connected to the database";
			}
			echo "<br>";

			$name = $this->getRequest()->getParam('name');
			$age = $this->getRequest()->getParam('age');
			$description = $this->getRequest()->getParam('description');
			$email = $this->getRequest()->getParam('email');
			$coloropt = $this->getRequest()->getParam('color-option');
			$mystate = $this->getRequest()->getParam('MyState');
			$gender = $this->getRequest()->getParam('mygender');

			$sql = "INSERT INTO `custum_popup_data`(`name`, `age`, `description`, `email`, `color-option`, `MyState`,`mygender`)  VALUES ('$name','$age','$description','$email','$coloropt','$mystate','$gender')";
			
			$conn->query($sql);
			echo "<script>alert('Successfully Submitted the Data')</script>";	
			*/
