<?php

namespace Chetu\NPop\Model\ResourceModel\Data;

use Magento\Framework\Model\ResourceModel\Db\Collection\AbstractCollection;

/**
 * Contact Resource Model Collection
 */
class Collection extends AbstractCollection
{
    /**
     * Initialize resource collection
     *
     * @return void
     */
    public function _construct()
    {
        $this->_init('Chetu\NPop\Model\Data', 'Chetu\NPop\Model\ResourceModel\Data');
    }
}
